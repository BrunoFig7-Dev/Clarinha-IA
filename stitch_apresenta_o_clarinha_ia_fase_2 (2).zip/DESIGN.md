---
name: Clarinha IA Enterprise Architecture
colors:
  surface: '#faf9f9'
  surface-dim: '#dadada'
  surface-bright: '#faf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f3'
  surface-container: '#eeeeed'
  surface-container-high: '#e9e8e8'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#584236'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f0f0'
  outline: '#8b7264'
  outline-variant: '#dfc0b0'
  surface-tint: '#994700'
  primary: '#994700'
  on-primary: '#ffffff'
  primary-container: '#f17300'
  on-primary-container: '#512200'
  inverse-primary: '#ffb68b'
  secondary: '#0062a0'
  on-secondary: '#ffffff'
  secondary-container: '#5fb0fd'
  on-secondary-container: '#00426e'
  tertiary: '#2c5cac'
  on-tertiary: '#ffffff'
  tertiary-container: '#6b96e9'
  on-tertiary-container: '#002d67'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbc8'
  primary-fixed-dim: '#ffb68b'
  on-primary-fixed: '#321200'
  on-primary-fixed-variant: '#753400'
  secondary-fixed: '#d0e4ff'
  secondary-fixed-dim: '#9bcaff'
  on-secondary-fixed: '#001d35'
  on-secondary-fixed-variant: '#00497a'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a41'
  on-tertiary-fixed-variant: '#034493'
  background: '#faf9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e3e2e2'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  display-sm:
    fontFamily: Space Grotesk
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Manrope
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Manrope
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.55'
    letterSpacing: '0'
  body-sm:
    fontFamily: Manrope
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: '1.5'
    letterSpacing: 0.01em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
  container-padding-mobile: 1rem
  container-padding-desktop: 2.5rem
  gutter: 1.5rem
---

## Brand & Style

O design system estabelece a linguagem visual corporativa e de dados para o ecossistema Clarinha IA (Fase 2). Concebido para equilibrar a credibilidade institucional corporativa com o dinamismo de inovação de ponta em inteligência artificial e engenharia de dados.

### Personalidade da Marca
- **Institucional & Tecnológica:** Confiança e rigor corporativo apoiados pelo azul institucional, combinados com a audácia do laranja elétrico para indicar computação cognitiva, pipelines ativos e inteligência em tempo real.
- **Clara & Executiva:** Fundo prioritariamente alvo e translúcido, transmitindo precisão analítica e facilidade de escaneabilidade para C-levels, engenheiros de dados e times de produto.
- **Estruturada & Sistemática:** Elementos visuais modulares que comunicam arquitetura de microsserviços, orquestração de pipelines e ciclos de homologação/produção com clareza cristalina.

### Estilo Visual
Um híbrido de **Corporate High-Tech Minimalista** com detalhes de **Precision Glassmorphism**. Telas arejadas sobre fundo branco puro (#FFFFFF), cartões com contornos sutis calibrados por azuis neutros, elevações difusas e tipografia de precisão técnica para métricas e títulos.

## Colors

A paleta de cores harmoniza a identidade vibrante do projeto com a robustez e seriedade da governança de dados corporativa.

### Cores Principais e de Marca
- **Primary (`#F17300` - Laranja Primário):** Utilizado para nós centrais de IA, ações de comando de alto impacto, estados de processamento em tempo real e destaque focal.
- **Secondary (`#0075BE` - Azul Institucional):** Utilizado para governança, barramentos de serviços, conectores de integração e hierarquia executiva confiável.
- **Tertiary (`#2154A3` - Azul Escuro / Navy):** Utilizado para fundos estruturais de alta densidade, headers de dados técnicos, nós de armazenamento enterprise e texto de alto contraste.
- **Neutral (`#A8A8A8` - Cinza Neutro):** Linhas de conexão de dados, delimitadores de cartões, ícones inativos e metadados secundários.

### Escala de Apoio e Subtons
- **Laranja Claro (`#FEB46E`):** Indicadores de alertas leves, badges de jobs em fila, fundos de chips e acentos quentes.
- **Azul Claro (`#6695DE`):** Rotas de ETL ativas, tags de homologação e badges técnicos.
- **Azul Suave (`#86ACE6`):** Linhas de conexão em repouso e realces sutis em relatórios executivos.
- **Superfícies & Fundos:** Branco puro (`#FFFFFF`) domina 75% da área útil, com áreas de contenção suaves em `#F8FAFC` e bordas estruturadas em `#E2E8F0` ou `#CBD5E1`.

## Typography

A união entre **Space Grotesk** e **Manrope** resolve a dualidade entre visão futurista de engenharia de IA e legibilidade analítica.

- **Space Grotesk (Títulos, Métricas e Labels Técnicos):** Confere traços de precisão computacional e postura de liderança técnica. É aplicada em IDs de pipelines, números analíticos de latência/throughput e status operacionais.
- **Manrope (Corpo, Justificativas Executivas e Descrições):** Proporciona equilíbrio tipográfico de leitura prolongada, clareza em tabelas de dados corporativos e alta legibilidade em ecrãs de densidades variadas.

## Layout & Spacing

O layout segue um grid fluido modular de 12 colunas com base de 8px, projetado especificamente para dashboards corporativos, diagramas de topologia de IA e infográficos executivos.

### Estrutura de Grid
- **Desktop (>= 1200px):** 12 colunas com gutter de `1.5rem` (`24px`) e margens laterais de `2.5rem` (`40px`). Ideal para layouts lado a lado de fluxogramas de ingestão e painéis de métricas.
- **Tablet (768px a 1199px):** 8 colunas com gutter de `1rem` (`16px`) e margens de `1.5rem` (`24px`).
- **Mobile (< 768px):** 4 colunas com gutter de `0.75rem` (`12px`) e margens de `1rem` (`16px`), onde componentes de arquitetura de dados se empilham verticalmente em formato de cards sequenciais.

### Densidade da Informação
A densidade é equilibrada: enquanto cartões de visão geral mantêm espaçamento generoso (`space-xl`), os blocos técnicos de topologia (jobs, nós de inferência, status de esteiras) utilizam espaçamento compacto (`space-xs` a `space-sm`) para garantir visualização unificada de ponta a ponta sem rolagem excessiva.

## Elevation & Depth

A profundidade é expressa de forma limpa, evitando sombras pesadas ou artificiais que comprometam a pureza do fundo branco `#FFFFFF`.

### Níveis de Elevação
- **Nível 0 (Plano de Fundo):** `#FFFFFF` sólido ou superfícies de agrupamento em `#F8FAFC` delimitadas por bordas monocromáticas sutis (`#E2E8F0`).
- **Nível 1 (Cartões de Arquitetura e Módulos):** Sombra ambiente hiper-difusa: `0 1px 3px rgba(33, 84, 163, 0.04), 0 4px 12px rgba(33, 84, 163, 0.03)` associada a uma borda técnica de `1px solid rgba(0, 117, 190, 0.12)`.
- **Nível 2 (Hover & Nós Ativos em Execução):** Elevação tátil ligeira com contorno intensificado pelo Laranja Primário: `0 6px 20px rgba(241, 115, 0, 0.08), 0 2px 6px rgba(33, 84, 163, 0.05)`, sugerindo atividade de processamento.
- **Nível 3 (Modais Executivos e Detalhes de Jobs):** `0 16px 36px rgba(33, 84, 163, 0.12), 0 4px 12px rgba(0, 0, 0, 0.03)` com suporte a backdrop blur de `12px` sobre fundo branco 90%.

## Shapes

O sistema adota cantos contidos e elegantes com nível de arredondamento `1` (base `0.25rem` / `4px`), gerando uma estética estruturada, precisa e industrial.

- **Contêineres de Dados e Cartões:** `rounded-lg` (`0.5rem` / `8px`) para delimitar seções de microsserviços e painéis de telemetria.
- **Badges de Status & Chips:** `rounded-md` (`0.375rem` / `6px`) para conferir formato de etiqueta técnica sem se tornar informal.
- **Botões e Ações:** `rounded` (`0.25rem` / `4px`), mantendo um apelo funcional e cirúrgico característico de consoles de dados corporativos.

## Components

### 1. Badges de Status (Ambiente & Pipelines)
- **Produção:** Fundo `#0075BE` a 10% com texto `#2154A3`, borda `1px solid #6695DE`. Ponto indicador pulsante opcional em `#0075BE`.
- **Homologação:** Fundo `#FEB46E` a 15% com texto `#C25600`, borda `1px solid #FEB46E`.
- **Job Ativo / IA Processing:** Fundo `#F17300` a 12% com texto `#F17300`, fonte `Space Grotesk`, peso 700 e `label-sm`.

### 2. Cartões de Arquitetura & Nós de Dados
- **Estrutura:** Fundo `#FFFFFF`, borda de `1px` em `rgba(0, 117, 190, 0.15)`, preenchimento interno de `1.25rem`.
- **Header do Card:** Ícone temático institucional (em tom `#0075BE` ou `#F17300`), título em Space Grotesk `headline-sm`, e tag de latência/versão no canto superior direito.
- **Hover:** Transição sutil de borda para `#F17300` a 50% com leve elevação de Nível 2.

### 3. Botões Executivos e Controles
- **Primary Action (Disparar IA / Exportar):** Fundo `#F17300`, texto `#FFFFFF`, cantos `0.25rem`, sombra de acento laranja suave. No hover: fundo escurecido para `#D96600`.
- **Secondary Action (Filtrar Parâmetros / Auditoria):** Fundo transparente, borda `1px solid #0075BE`, texto `#0075BE`.
- **Ghost Action:** Texto `#2154A3`, fundo transparente, foco com anel `#86ACE6`.

### 4. Linhas e Conectores de Fluxo (Data Pipeline Connectors)
- **Fluxo Ativo:** Traçado vetorial contínuo de `2px` em `#F17300` com animação gradiente suave em direção ao destino.
- **Fluxo em Espera / Arquivado:** Traçado pontilhado de `1.5px` em `#A8A8A8`.

### 5. Indicadores Numéricos (KPIs Executivos)
- **Destaque:** Números volumosos em Space Grotesk `display-sm` na cor `#2154A3`, acompanhados de rótulo descritivo em Manrope `body-sm` (`#A8A8A8`) e variação percentual destacada em tag verde ou laranja.